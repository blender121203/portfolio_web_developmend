<?php
 include("db.php");
 session_start();
    if (isset($_POST["name"]) && isset($_POST["phonenumber"]))
    {
////////////////// Проверка поля логин на пустоту
        if ($_POST["name"] != ""){$name = $_POST["name"];}else{
            $error .= "Вы не заполнили поле Логин<br>";
        }
////////////////// Проверка поля пароль на пустоту
        if ($_POST["phonenumber"] != ""){$phonenumber = $_POST["phonenumber"];}else{
            $error .= "Вы не заполнили поле Пароль<br>";
        }
        if($error=='')
               {
               $sql = $db -> query(" INSERT INTO `User` (`name`, `phonenumber`) 
               VALUES ('$name', '$phonenumber'); ");
            $message .= "Вы успешно зарегистртровались";
               }
        //Формируем массив для отправки данных
        // Проверка на существующего пользователя в БД
    
    $result=array
    (
        "error"=> $error
    );
    //Отправка данных на клиент
    echo json_encode($result);
   }
?>


<?php
/*
include("db.php");
    if (isset($_POST["name"]) && isset($_POST["phonenumber"]))
    {
////////////////// Проверка поля логин на пустоту
        if ($_POST["name"] != ""){$name = $_POST["name"];}else{
            $error .= "Вы не заполнили поле Логин<br>";
        }
////////////////// Проверка поля пароль на пустоту
        if ($_POST["phonenumber"] != ""){$phonenumber = $_POST["phonenumber"];}else{
            $error .= "Вы не заполнили поле Пароль<br>";
        }
        if($error=='')
               {
               $sql = $db -> query("INSERT INTO `User` (`name`, `phonenumber`) VALUES ('$name', '$phonenumber');");
            $message .= "Вы успешно зарегистртровались<br>";
               }
    }*/
?>

<!doctype html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
     <title>Регистрация пользователя Ajax</title>
     <!-- <script src="https://ajax.googleapis.com/ajax/libs/jguery/2.0.3/jquery.min.js"></script> -->
      <!--  <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>  -->
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
     <script src="http://g99145lt.beget.tech/prace_4/ajax.js"></script>
</head>
<body>
     <form action="" id="ajax_form" method="POST">
          <input type="text" name="name" placeholder="Ваше имя"/><br>
          <input type="text" name="phonenumber" placeholder="Ваш телефон"/><br>
          <input type="submit" value="Отправить" id="btn"/>
     </form>
     <br>
     <div id="result_form"></div>
     
     
     
  <!--    <script>
        $( document ).ready(function(){
  $("#btn").click(
       function(){
           sendAjaxForm('result_form', 'ajax_form', 'action_ajax_form.php');
            return false;
       }
   );
   });
  
   function sendAjaxForm(result_form, ajax_form, url){
   jQuery.ajax({
        url:"action_ajax_form.php",
        type:"POST",
        dataType:"html",
        data: jQuery("#"+ajax_form).serialize(),
        success: function(response){
             result = jQuery.parseJSON(response);
             document.getElementById(result_form).innerHTML = "Имя: "+result.name+"<br>Телефон: "+result.phonenumber;
       },
       error: function(response){                
            document.getElementById(result_form).innerHTML = "Ошибка. Данные не отправленны";
       }
   });
   }
  </script> -->
</body>
</html>
<?php
$dom = new DomDocument('1.0');
$books = $dom->appendChild($dom->createElement('root'));
$book = $books->appendChild($dom->createElement('Employee'));
$book->setAttribute('name', 'Иванов Иван');

$title = $book->appendChild($dom->createElement('Role'));
$title->appendChild(
    $dom->createTextNode('1'));
    
    
$title_2 = $book->appendChild($dom->createElement('login'));
$title_2->appendChild(
    $dom->createTextNode('supermanager'));
    
$title_3 = $book->appendChild($dom->createElement('pass'));
$title_3->appendChild(
    $dom->createTextNode('qwerty'));    
  $dom->formatOutput = true;
  $test_8= $dom->saveXML();
  $dom->save('file.xml');
?>
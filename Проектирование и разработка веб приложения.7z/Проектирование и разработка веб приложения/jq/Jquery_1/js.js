$(document).ready(function() {
    $('#hide').click(() => {
        $('#img').hide(200)
    });
    $('#show').click(() => {
        $('#img').show(200)
    });


    $('#run').click(function(e) {
        $('#block').animate({ opacity: '0', left: '400' }, 3000)
        $('#block').animate({ opacity: '1', left: '0', width: '100', height: '100' }, 3000)
    });

    $('#creat').click(function(e) {
        $('#Block').animate({ opacity: '0', }, 2000)
        $('#Block').animate({ left: '50', opacity: '1' }, 2000)
        $('#Block').animate({ opacity: '1', left: '50', width: $('#Block').width() * 2, height: $('#Block').height() * 2 }, 2000)
        $('#Block').animate({ top: '100', }, 2000)
        setTimeout(() => {
            $('#Block').css({
                'background-color': 'red',
            });
        }, 8000)
        $('#Block').animate({ opacity: '0', }, 2000)
    });

});
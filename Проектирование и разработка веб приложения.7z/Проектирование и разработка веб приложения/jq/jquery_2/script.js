$(document).ready(function() {
    $('.block').hide();

    $(function() {
        $(window).scroll(function() {
            if ($(this).scrollTop() > 100) {
                $('.block').fadeIn();
            } else {
                $('.block').fadeOut();
            }
        })
        $('.block img').click(function() {
            console.log(1);
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
    });

});
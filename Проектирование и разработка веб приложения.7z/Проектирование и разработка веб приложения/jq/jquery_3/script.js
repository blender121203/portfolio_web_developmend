$(document).ready(function() {



    $('li').click(function() {
        var number = $(this).index();
        $('h2').hide().eq(number).show();
        $('p').hide().eq(number).show();
        $(this).toggleClass('active inactive');
        $('li').not(this).removeClass('active').addClass('inactive');
    });

    $('h2').not(':first').hide();
    $('p').not(':first').hide();
});
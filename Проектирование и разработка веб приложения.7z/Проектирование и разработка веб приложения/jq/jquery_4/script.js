$(document).ready(function() {
    $("#contentbox").keyup(function() {
        var box = $(this).val();
        var main = box.length * 100;
        var value = (main / 50);
        var count = 50 - box.length;

        if (box.length <= 50) {
            $('#count').html(count);
            $('#bar').animate({ "width": value + '%', }, 1);
        }
        return false;
    });
});